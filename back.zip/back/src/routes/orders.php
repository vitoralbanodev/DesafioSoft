<?php
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Methods: GET, POST, DELETE");
    header("Access-Control-Allow-Headers: Content-Type");

    require('../services/order.php');

    $order = new Order();

    $method = $_SERVER['REQUEST_METHOD'];
    $jsonData = file_get_contents('php://input');
    $params = json_decode($jsonData, true);
    
    if($method === "GET"){
        $orderList = $order->getOrders();

        echo json_encode($orderList);
    }
    elseif($method === "POST"){
        if($params != null && array_key_exists("condition", $params)) 
            echo json_encode(methods->getSpecificSelect($params['column'], $params['condition']));
        else{
            $order->createOrder($params['total'], $params['tax'], $params['date']);
        }
    }
    elseif($method === "DELETE"){
        methods->delete($params['code'], $params['table']);
    }