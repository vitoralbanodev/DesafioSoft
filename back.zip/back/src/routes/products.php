<?php
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Methods: GET, POST, DELETE");
    header("Access-Control-Allow-Headers: Content-Type");

    require('../services/products.php');

    $products = new Products();

    $method = $_SERVER['REQUEST_METHOD'];
    $jsonData = file_get_contents('php://input');
    $params = json_decode($jsonData, true);
    
    if($method === "GET"){
        $categoryList = $products->getProducts();

        echo json_encode($categoryList);
    }
    elseif($method === "POST"){
        if($params != null && array_key_exists("condition", $params)) 
            echo json_encode($products->getSpecificSelect($params['column'], $params['condition']));
        else{
            $name = filter_input(INPUT_POST, 'name');
            $amount = filter_input(INPUT_POST, 'amount');
            $unitPrice = $_POST['price'];
            $category = $_POST['category'];
            
            $products->createProduct($name, $amount, $unitPrice, $category);
        }
    }
    elseif($method === "DELETE"){
        methods->delete($params['code'], $params['table']);
    }
    elseif($method === "PATCH"){
        $products->update($params['value'], $params['code']);
    }