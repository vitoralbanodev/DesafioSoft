<?php
    require('../index.php');

    class Products{

        function createProduct($name, $amount, $price, $category){
            $sql = myPDO->prepare('INSERT INTO products (name, amount, price, category_code) VALUES (:name, :amount, :price, :category)');
            $sql->bindValue(':name', $name, PDO::PARAM_STR);
            $sql->bindValue(':amount', $amount, PDO::PARAM_INT);
            $sql->bindValue(':price', $price, PDO::PARAM_STR);
            $sql->bindValue(':category', $category);
            $sql->execute();
        }

        function getProducts(){
            $queryString = "SELECT products.*, categories.tax as tax, categories.name as category_name 
            FROM products JOIN categories ON products.category_code = categories.code ORDER BY code ASC";
            $sql = myPDO->query($queryString);
            $data = $sql->fetchAll();

            return $data;
        }

        function getSpecificSelect($column, $condition){
            $queryString = "SELECT products.*, categories.tax as tax, categories.name as category_name 
            FROM products JOIN categories ON products.category_code = categories.code WHERE $column"."="."$condition ORDER BY code ASC";
            $sql = myPDO->query($queryString);
            $data = $sql->fetchAll();

            return $data;
        }

        function update($value, $code){
            $queryString = "UPDATE products SET amount = $value WHERE products.code = $code";
            echo $queryString;
            $sql = myPDO->query($queryString);
            $sql->execute();
        }
    }
?>