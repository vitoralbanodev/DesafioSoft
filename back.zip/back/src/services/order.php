<?php
    require('../index.php');

    class Order
    {

        function createOrder($total, $tax, $date){
            error_log(print_r("total".$total));
            error_log(print_r("tax".$tax));
            error_log(print_r("date".$date));
            $sql = myPDO->prepare('INSERT INTO orders (total, tax, purchase_date) VALUES (:total, :tax, :date)');
            $sql->bindValue(':total', $total, PDO::PARAM_STR);
            $sql->bindValue(':tax', $tax, PDO::PARAM_INT);
            $sql->bindValue(':date', $date, PDO::PARAM_STR);
            $sql->execute();
        }

        function getOrders(){
            $sql = myPDO->query("SELECT * FROM orders ORDER BY code ASC");
            $data = $sql->fetchAll();

            return $data;
        }
    }
?>