<?php
    require('../index.php');

    class ShoppingCart
    {

        function createCategory($name, $tax){
            $sql = myPDO->prepare('INSERT INTO categories (code, name, tax) VALUES (001, :name, :tax)');
            $sql->bindValue(':name', $name);
            $sql->bindValue(':tax', (int)$tax);
           $sql->execute();
        }

        function getCategories(){
            $statement1 = myPDO->query("SELECT * FROM categories");
            $data = $statement1->fetch();

            return $data;
        }

        function deleteCategory($code){
            $sql = myPDO->prepare('DELETE FROM categories WHERE code = :code');
            $sql->bindValue(':code', (int)$code);
            $sql->execute();
        }
    }
?>