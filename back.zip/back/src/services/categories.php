<?php
    require('../index.php');

    class Categories{

        function createCategory($name, $tax){
            $sql = myPDO->prepare('INSERT INTO categories (name, tax) VALUES (:name, :tax)');
            $sql->bindValue(':name', $name, PDO::PARAM_STR);
            $sql->bindValue(':tax', $tax, PDO::PARAM_INT);
           $sql->execute();
        }

        function getCategories(){
            $queryString = "SELECT * FROM categories ORDER BY code ASC";
            $sql = myPDO->query($queryString);
            $data = $sql->fetchAll();

            return $data;
        }
    }
?>