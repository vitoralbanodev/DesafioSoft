var url = defineRouteURL("categories");

async function createCategory(){
    var categoryName = document.getElementById("categoryName").value.replace(/[^a-z0-9 ]/gi, '');
    if(await verifyExistence(categoryName, "categories", "name")){
        var formData = new FormData(document.getElementById("category-form"))
        fetch(url,{
            method: "POST",
            body: formData
        }).then(response => {
            if (response.ok){
                alert("A new category has been created successfully!");
            }
            else{
                console.error("It wasn't possible to create a new category")
            }
        })
        location.reload();
    }
    else alert(`Already exists a category named "${categoryName}"`)
}

async function fillTable(){
    cleanTable();
    const table = document.getElementById("tableBody")
    getJsonTable("categories").then(categories =>{
        categories.forEach(async category => {
            let taxNumber = numberRegex(category.tax.toString());
            let categoryName = category.name;
            let categoryRegex = categoryName.replace(/[^a-z0-9 ]/gi, '');
            let canDelete = await verifyExistence(categoryName, "products", "categories.name");
            if(verifyName(categoryRegex) && verifyNumbers(taxNumber) && verifyTaxNumber(taxNumber))
            {
                let row = table.insertRow();
                let code = row.insertCell();
                code.innerHTML = category.code;
                let name = row.insertCell();
                name.innerHTML = categoryRegex;
                let tax = row.insertCell();
                tax.innerHTML = taxNumber + "%";
                let deleteButton = row.insertCell();
                deleteButton.innerHTML = `<button class='labels' type='submit' id='deleteButton' onclick='deleteRow(` + JSON.stringify(category.code) + `, "categories", ` + canDelete + `)'><i class="fa-solid fa-trash"></i></button>`;
            }
            else deleteRowOnLoad(category.code, "categories")
        });
    });
}