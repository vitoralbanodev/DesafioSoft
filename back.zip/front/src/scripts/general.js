function cleanTable(){
    var table = document.getElementsByClassName("genericTable")[0]
    var rowCount = table.rows.length;
    for (var i = rowCount - 1; i > 0; i--){
        table.deleteRow(i);
    }
}

function defineRouteURL(table){
    return 'http://localhost/routes/' + table + '.php'
}

async function getJsonTable(table){
    var url = defineRouteURL(table);
    var response  = await fetch(url, {
        method: "GET"
    });

    var tableJson = await response.json();
    return tableJson ? tableJson : [];
}

async function getJsonTableCondition(table, column, condition){
    var url = defineRouteURL(table);
    var response = await fetch(url, {
        headers: {"Content-Type" : "application/json"},
        method: "POST",
        body: JSON.stringify({
            'table': table,
            'column': column,
            'condition': condition
        })});
    var tableJson = await response.json()
    return tableJson ? tableJson : [];
}

function getLocalStorage(table){
    var tableJson = localStorage.getItem(table);

    return tableJson ? JSON.parse(tableJson) : [];
}

function deleteRow(code, key, validate){
    if(confirm("Are you sure you want to remove this?") && validate){
        console.log("entrou")
        deleteRowOnLoad(code, key)
    }
    else alert("It was not possible to delete this item! \nPlease verify if it is not linked with another table.")
}

function deleteRowOnLoad(code, key){
    console.log("code -> " + code )
    console.log("key -> " + key )
    fetch(url, {
        headers: {"Content-Type" : "application/json"},
        method: "DELETE",
        body: JSON.stringify({
            'table': key,
            'code': code
        })
    });
    location.reload()
}

async function verifyExistence(name, table, column){
    var boolean = true;
    var nameString = "LOWER('" + name + "')";
    var column = "LOWER("+column+")";
    var list = await getJsonTableCondition(table, column, nameString);
    if(list.length > 0){
        boolean = false;   
    }

    return boolean;
}

function numberRegex(string){
    return string.replace(/[^0-9,.]/g,'');
}

function verifyNumbers(number){
    var boolean = true;
    if(number.constructor === Array)
    {
        number.forEach(data => {
            if(data == "" || isNaN(data)) boolean = false; 
        });
    }
    else{
        
        boolean = (!number == "") && !isNaN(number);
    }

    return boolean;
}

function verifyTaxNumber(tax){
    const taxNumber = parseInt(tax)
    if(taxNumber < 0){
        alert("The tax amount can't be a negative number.")
        return false;
    }
    if(taxNumber > 100){
        alert("The tax amount can't exceed 100.")
        return false;
    }

    return true;
}

function verifyName(name){
    var boolean = true;
    if(name.constructor === Array)
        {
            name.forEach(data => {
                if(data.length <= 3 || data.length > 25) boolean = false; 
            });
        }
        else{
            boolean = name.length > 3 && name.length <= 25;
        }
        
    return boolean;
}
// FUNÇÕES CORRIGIDAS COM BANCO

function verifyBoughtItem(itemName){
    var canDelete = true
    var dataList = getJsonTable("order_item");
    dataList.forEach(data => {
        data.productList.forEach(product => {
            if(product.name === itemName){
                canDelete = false;
            }
        });
    })

    return canDelete;
}

//codigo MORTO

// if(key == "shoppingCart")
// {
//     var productList = getJsonTable("products");
//     productList.forEach(product => {
//         if(data.name == product.name && verifyNumbers(data.amount)){
//             product.amount += parseInt(data.amount);
//         }
//     });
//     localStorage.setItem("products", JSON.stringify(productList));
// }
//