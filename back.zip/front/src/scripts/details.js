function pickUrlParams(){
    const urlParams = new URLSearchParams(window.location.search);
    var historyList = getJsonTable("history");
    var code = urlParams.get("code");
    historyList.forEach(data => {
        if(data.code === code){
            fillTable(data)
        }
    });
}

function fillTable(dataHistory){
    cleanTable();
    var dataProducts = dataHistory.productList;
    const table = document.getElementById("tableBody")
    dataProducts.forEach(data =>{
            let row = table.insertRow();
            let code = row.insertCell();
            code.innerHTML = data.code;
            let name = row.insertCell();
            name.innerHTML = data.name.replace(/[^a-z0-9 ]/gi, '');
            let category = row.insertCell();
            category.innerHTML = data.category.replace(/[^a-z0-9 ]/gi, '');
            let amount = row.insertCell();
            amount.innerHTML = data.amount.replace(/[^a-z0-9 ]/gi, '');
            let tax = row.insertCell();
            tax.innerHTML = "$" + data.tax.replace(/[^a-z0-9. ]/gi, '');
            let total = row.insertCell();
            total.innerHTML = "$" + data.total.replace(/[^a-z0-9. ]/gi, '');
    });

    document.getElementById("taxLabel").value = dataHistory.tax;
    document.getElementById("totalLabel").value = dataHistory.total;
}