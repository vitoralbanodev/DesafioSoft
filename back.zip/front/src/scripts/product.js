var url = defineRouteURL("products");

function fillCategorySelect(){
    var selectInput = document.getElementById("productSelect");
    getJsonTable("categories").then(categories => {
        categories.forEach(category => {
            var taxNumber = category.tax;
            if(verifyNumbers(taxNumber) && verifyTaxNumber(taxNumber)){
                selectInput.innerHTML += `<option value="` + category.code + `">` + category.name.replace(/[^a-z0-9 ]/gi, '') + `</option>`
            }
            else deleteRowOnLoad(category.code, "categories")
        });
    });
}

function fillTable(){
    cleanTable();
    const table = document.getElementById("tableBody")
    getJsonTable("products").then(productList => {
        productList.forEach(async data => {
            let productNameRegex = data.name.replace(/[^a-z0-9 ]/gi, '');
            let amountNumber = numberRegex('' + data.amount);
            let unitPriceNumber = numberRegex('' + data.price);
            let categoryRegex = data.category_name.replace(/[^a-z0-9 ]/gi, '');
            // let canDelete = await verifyCanDelete(productNameRegex);
            if(verifyName([productNameRegex, categoryRegex]) && verifyNumbers([amountNumber, unitPriceNumber]))
            {
                let row = table.insertRow();
                let code = row.insertCell();
                code.innerHTML = data.code;
                let name = row.insertCell();
                name.innerHTML = productNameRegex;
                let amount = row.insertCell();
                amount.innerHTML = amountNumber;
                let unitPrice = row.insertCell();
                unitPrice.innerHTML = "$" + unitPriceNumber;
                let category = row.insertCell();
                category.innerHTML = categoryRegex;
                // let deleteButton = row.insertCell();
                // deleteButton.innerHTML = `<button class='labels' type='submit' id='deleteButton' onclick='deleteRow(` + JSON.stringify(data.code) + `, "products", ` + canDelete + `)'><i class="fa-solid fa-trash"></i></button>`;
            }
            // else deleteRowOnLoad(data.code, "products")
        });
    });
}

async function createProduct(){
    var productName = document.getElementById("largerInput").value.replace(/[^a-z0-9 ]/gi, '');
    if(await verifyExistence(productName, "products")){
        var formData = new FormData(document.getElementById("productForm"))
        fetch(url,{
            method: "POST",
            body: formData
        }).then(response => {
            if (response.ok){
                alert("A new product has been created successfully!");
            }
            else{
                console.error("It wasn't possible to create a new product")
            }
        })
    }
}

// function verifyProduct(amount, unitPrice, productName){
//     return (verifyName(productName) && amount.length >= 1 && unitPrice.length >= 1)
// }

// function verifyCanDelete(productNameRegex){
//     if(verifyExistence(productNameRegex, "shoppingCart"))
//         return verifyBoughtItem(productNameRegex);

//     return false;
// }